
import os
import sys
import time

LOCK_FILE = "lockfile.lock"
LOCK_TIME = 60 

def is_locked():
    if os.path.exists(LOCK_FILE):
        with open(LOCK_FILE, 'r') as f:
            last_run_time = float(f.read().strip())
            current_time = time.time()
            if current_time < last_run_time + LOCK_TIME:
                return True
    return False

def create_lock():
    try:
        with open(LOCK_FILE, 'w') as f:
            f.write(str(time.time()))
    except IOError as e:
        print(f"Error creating lock file: {e}")
        sys.exit(1)

def remove_lock():
    try:
        if os.path.exists(LOCK_FILE):
            os.remove(LOCK_FILE)
    except IOError as e:
        print(f"Error removing lock file: {e}")

def check_lock():
    if is_locked():
        remaining_time = LOCK_TIME - (time.time() - float(open(LOCK_FILE).read().strip()))
        print(f"The application is already running. Please wait {int(remaining_time)} seconds before opening it again.")
        sys.exit(1)
    create_lock()