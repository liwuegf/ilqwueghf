import os
import shutil
import sys
import winreg as reg

class StartupManager:
    def __init__(self):
        self.script_name = os.path.basename(sys.argv[0])
        self.script_path = os.path.abspath(sys.argv[0])
        self.startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
        self.registry_key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"

    def get_startup_folder(self):
        return self.startup_folder

    def add_to_startup(self):
        try:
            shutil.copy(self.script_path, self.get_startup_folder())
            print(f"Script successfully added to Startup: {self.startup_folder}\\{self.script_name}")
        except Exception as e:
            print(f"Error adding script to Startup: {e}")

    def add_to_registry(self):
        try:
            key = reg.HKEY_CURRENT_USER
            reg_key = reg.OpenKey(key, self.registry_key_path, 0, reg.KEY_WRITE)
            reg.SetValueEx(reg_key, self.script_name, 0, reg.REG_SZ, self.script_path)
            reg.CloseKey(reg_key)
            print(f"Script successfully added to Registry for startup: {self.script_name}")
        except Exception as e:
            print(f"Error adding script to registry: {e}")

    def setup(self):
        self.add_to_startup()
        self.add_to_registry()
        print("Script is now set to run on startup.")

if __name__ == "__main__":
    startup_manager = StartupManager()
    startup_manager.setup()
