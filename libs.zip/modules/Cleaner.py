import os

def cleaner():
    files = ["output.zip", "screenshot.png", "cookie_db"]
    
    # Loop through each file in the list and remove it
    for file in files:
        try:
            if os.path.exists(file):  # Check if the file exists before attempting to remove it
                os.remove(file)
                print(f"Removed: {file}")
            else:
                print(f"File not found: {file}")
        except Exception as e:
            print(f"Error removing {file}: {e}")
